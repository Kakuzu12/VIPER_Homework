//
//  Presenter.swift
//  VIPER_attempt
//
//  Created by Егор on 19.07.2020.
//  Copyright © 2020 Егор. All rights reserved.
//

import Foundation

protocol PresenterProtocol {
  func didGetDataFromPresenter(data : String)
}

final class Presenter : InteractorProtocol{
  
  var interactor : Interactor?
  var presenterProtocol : PresenterProtocol?
  
  func didGetDataFromInteractor(data: String) {
    presenterProtocol?.didGetDataFromPresenter(data: data)
  }
  
  func getDataFromInteractor(){
    interactor?.getDataFromOutside()
  }
  
}
