//
//  ViewController.swift
//  VIPER_attempt
//
//  Created by Егор on 19.07.2020.
//  Copyright © 2020 Егор. All rights reserved.
//

import UIKit

class ViewController: UIViewController,PresenterProtocol {

  
  
    @IBOutlet weak var lbl: UILabel!
    var presenter : Presenter?
  
  
  override func viewDidLoad() {
    super.viewDidLoad()
    // Do any additional setup after loading the view, typically from a nib.
    presenter?.getDataFromInteractor()
  }

  func didGetDataFromPresenter(data: String) {
    lbl.text = data
  }
  
}

