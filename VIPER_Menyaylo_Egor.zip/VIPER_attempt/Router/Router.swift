//
//  Router.swift
//  VIPER_attempt
//
//  Created by Егор on 19.07.2020.
//  Copyright © 2020 Егор. All rights reserved.
//

import Foundation
import UIKit

final class Router{
  
  class func getRootScreen() -> UIViewController{
    
    let storyboard = UIStoryboard(name: "Main", bundle: nil)
    let viewController = storyboard.instantiateViewController(withIdentifier: "ViewController") as! ViewController
    let presenter = setUpPresenter(forViewController: viewController)
    
    setUpInteractor(forPresenter: presenter)
    
    viewController.presenter = presenter
    
    return viewController
  }
  
  private class func setUpPresenter(forViewController viewController : ViewController) -> Presenter{
  
    let presenter = Presenter()

    presenter.presenterProtocol = viewController
    
    return presenter
  }
  
  private class func setUpInteractor(forPresenter presenter : Presenter){
    
    let interactor = Interactor()

    interactor.interactorProtocol = presenter
    
    presenter.interactor = interactor
  }
  
}
