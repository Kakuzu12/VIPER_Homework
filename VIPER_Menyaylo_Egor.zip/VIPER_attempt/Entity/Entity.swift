//
//  Entity.swift
//  VIPER_attempt
//
//  Created by Егор on 20.07.2020.
//  Copyright © 2020 Егор. All rights reserved.
//

import Foundation

final class Entity{
  
   var someData:String?
  
}
