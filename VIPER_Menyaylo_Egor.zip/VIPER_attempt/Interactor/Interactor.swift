//
//  Interactor.swift
//  VIPER_attempt
//
//  Created by Егор on 19.07.2020.
//  Copyright © 2020 Егор. All rights reserved.
//

import Foundation

protocol InteractorProtocol {
  func didGetDataFromInteractor(data : String)
}

final class Interactor{
  
  var interactorProtocol : InteractorProtocol?
  
  func getDataFromOutside(){
    let data = "Label"
    
    interactorProtocol?.didGetDataFromInteractor(data: data)
  }
}
